const badgeInstance = (
  <p>Badges <Badge>42</Badge></p>
);

React.render(badgeInstance, mountNode);
