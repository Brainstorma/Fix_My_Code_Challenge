# react-bootstrap-bower

[Bootstrap 3](http://getbootstrap.com) components built with [React](http://facebook.github.io/react/)

This repo contains built AMD modules and standalone browser globals.

There is a separate [source repo](https://github.com/react-bootstrap/react-bootstrap).

A [docs site](http://react-bootstrap.github.io) with live editable examples.

[![Build Status](https://travis-ci.org/react-bootstrap/react-bootstrap.svg)](https://travis-ci.org/react-bootstrap/react-bootstrap) [![Bower version](https://badge.fury.io/bo/react-bootstrap.svg)](http://badge.fury.io/bo/react-bootstrap)
